﻿using UnityEngine.Events;
using UnityEngine.UI;

//NOT IN USE ATM
//public interface IControlMode
//{
//    // Method to set the IsHeldDown state
//    void SetIsHeldDown(bool value);
//    void LinkToActions(Button up, Button Down, Button Left, Button right);
//    void DelinkToActions(Button up, Button Down, Button Left, Button right);
//}